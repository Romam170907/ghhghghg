﻿using System;
using System.Drawing;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
namespace lib
{
    public partial class BooksForm : Form
    {
        private FlowLayoutPanel flowLayoutPanel;
        private string connectionString = "Server=localhost;Port=3307;Database=LibraryDB;Uid=root;Pwd=;";
        public BooksForm()
        {
            this.Text = "Список книг";
            this.Size = new Size(800, 500);
            flowLayoutPanel = new FlowLayoutPanel { Dock = DockStyle.Fill, AutoScroll = true, Padding = new Padding(10) };
            this.Controls.Add(flowLayoutPanel);
            LoadBooks();
        }

        private void LoadBooks()
        {
            using (MySqlConnection conn = new MySqlConnection(connectionString))
            {
                conn.Open();
                string query = @"SELECT b.title, b.author, b.publisher, b.year, t.name AS topic 
                                 FROM books b 
                                 LEFT JOIN topics t ON b.topic_id = t.topic_id";
                MySqlCommand cmd = new MySqlCommand(query, conn);
                MySqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    Panel card = new Panel { Width = 350, Height = 150, BorderStyle = BorderStyle.FixedSingle, Margin = new Padding(8), BackColor = Color.WhiteSmoke };
                    card.Controls.Add(new Label { Text = reader["title"].ToString(), Font = new Font("Segoe UI", 11, FontStyle.Bold), Location = new Point(5, 5), AutoSize = true });
                    card.Controls.Add(new Label { Text = $"Автор: {reader["author"]}", Location = new Point(5, 35), AutoSize = true });
                    card.Controls.Add(new Label { Text = $"Издатель: {reader["publisher"]}", Location = new Point(5, 60), AutoSize = true });
                    card.Controls.Add(new Label { Text = $"Год: {reader["year"]}", Location = new Point(5, 85), AutoSize = true });
                    card.Controls.Add(new Label { Text = $"Тема: {reader["topic"]}", Location = new Point(5, 110), AutoSize = true });
                    flowLayoutPanel.Controls.Add(card);
                }
                reader.Close();
            }
        }
        private void BooksForm_Load(object sender, EventArgs e)
        {

        }
    }
}
