﻿using System;
using System.Drawing;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace lib
{
    public partial class SubscriptionsForm : Form
    {


        private FlowLayoutPanel flowLayoutPanel;
        private string connectionString = "Server=localhost;Port=3307;Database=LibraryDB;Uid=root;Pwd=;";
        public SubscriptionsForm()
        {
            this.Text = "Журнал выдач книг";
            this.Size = new Size(850, 550);
            flowLayoutPanel = new FlowLayoutPanel { Dock = DockStyle.Fill, AutoScroll = true, Padding = new Padding(10) };
            this.Controls.Add(flowLayoutPanel);
            LoadSubscriptions();
        }

        private void LoadSubscriptions()
        {
            using (MySqlConnection conn = new MySqlConnection(connectionString))
            {
                conn.Open();
                string query = @"SELECT r.full_name, b.title, s.issue_date, s.return_date, s.advance 
                                 FROM subscriptions s
                                 JOIN readers r ON s.reader_id = r.reader_id
                                 JOIN books b ON s.book_id = b.book_id AND s.library_id = b.library_id";
                MySqlCommand cmd = new MySqlCommand(query, conn);
                MySqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    Panel card = new Panel { Width = 360, Height = 160, BorderStyle = BorderStyle.FixedSingle, Margin = new Padding(8), BackColor = Color.LightYellow };
                    card.Controls.Add(new Label { Text = $"Читатель: {reader["full_name"]}", Font = new Font("Segoe UI", 10, FontStyle.Bold), Location = new Point(5, 5), AutoSize = true });
                    card.Controls.Add(new Label { Text = $"Книга: {reader["title"]}", Location = new Point(5, 35), AutoSize = true });
                    card.Controls.Add(new Label { Text = $"Дата выдачи: {((DateTime)reader["issue_date"]).ToShortDateString()}", Location = new Point(5, 60), AutoSize = true });

                    string returnDate = reader["return_date"] == DBNull.Value ? "Не возвращена" : ((DateTime)reader["return_date"]).ToShortDateString();
                    card.Controls.Add(new Label { Text = $"Дата возврата: {returnDate}", Location = new Point(5, 85), AutoSize = true });
                    card.Controls.Add(new Label { Text = $"Залог: {reader["advance"]} руб.", Location = new Point(5, 110), AutoSize = true });

                    flowLayoutPanel.Controls.Add(card);
                }
                reader.Close();
            }
        }
        private void SubscriptionsForm_Load(object sender, EventArgs e)
        {

        }
    }
}
