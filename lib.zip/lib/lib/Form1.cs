using System;
using System.Drawing;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace lib
{
    public partial class Form1 : Form
    {
        private string connectionString = "Server=localhost;Port=3307;Database=LibraryDB;Uid=root;Pwd=;";

        private FlowLayoutPanel flowLayoutPanel;
        private Button btnLoadReaders, btnShowBooks, btnShowSubscriptions;
        public Form1()
        {
            InitializeComponent();
            SetupUI();
            LoadReaders();
        }
        private void SetupUI()
        {
            this.Text = "������������ ������� - ��������";
            this.Size = new Size(900, 600);

            // ������ � ��������
            Panel topPanel = new Panel { Height = 50, Dock = DockStyle.Top };
            btnLoadReaders = new Button { Text = "��������", Location = new Point(10, 10), Width = 120 };
            btnShowBooks = new Button { Text = "�����", Location = new Point(140, 10), Width = 120 };
            btnShowSubscriptions = new Button { Text = "������", Location = new Point(270, 10), Width = 120 };

            btnLoadReaders.Click += (s, e) => LoadReaders();
            btnShowBooks.Click += (s, e) => { new BooksForm().ShowDialog(); };
            btnShowSubscriptions.Click += (s, e) => { new SubscriptionsForm().ShowDialog(); };

            topPanel.Controls.Add(btnLoadReaders);
            topPanel.Controls.Add(btnShowBooks);
            topPanel.Controls.Add(btnShowSubscriptions);

            // FlowLayoutPanel ��� ��������
            flowLayoutPanel = new FlowLayoutPanel
            {
                Dock = DockStyle.Fill,
                AutoScroll = true,
                Padding = new Padding(10),
                FlowDirection = FlowDirection.TopDown,
                WrapContents = true
            };

            this.Controls.Add(flowLayoutPanel);
            this.Controls.Add(topPanel);
        }

        private void LoadReaders()
        {
            flowLayoutPanel.Controls.Clear();

            using (MySqlConnection conn = new MySqlConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    string query = "SELECT full_name, address, phone FROM readers";
                    MySqlCommand cmd = new MySqlCommand(query, conn);
                    MySqlDataReader reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {
                        string fullName = reader["full_name"].ToString();
                        string address = reader["address"].ToString();
                        string phone = reader["phone"].ToString();

                        // ������� �������� �������
                        Panel card = CreateReaderCard(fullName, address, phone);
                        flowLayoutPanel.Controls.Add(card);
                    }
                    reader.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("������ ��������: " + ex.Message);
                }
            }
        }

        private Panel CreateReaderCard(string fullName, string address, string phone)
        {
            Panel card = new Panel
            {
                Width = 320,
                Height = 180,
                BorderStyle = BorderStyle.FixedSingle,
                Margin = new Padding(10),
                BackColor = Color.FromArgb(240, 248, 255) // Light cyan
            };

            // ��������� ��� �� �����, ���� ����� (����� �������� ��� ����)
            Label lblName = new Label
            {
                Text = fullName,
                Font = new Font("Segoe UI", 12, FontStyle.Bold),
                Location = new Point(10, 10),
                AutoSize = true,
                ForeColor = Color.DarkBlue
            };

            Label lblEmail = new Label
            {
                Text = $"Email: {GenerateEmail(fullName)}", // ����-email
                Location = new Point(10, 45),
                AutoSize = true
            };

            Label lblPhone = new Label
            {
                Text = $"�������: {phone}",
                Location = new Point(10, 75),
                AutoSize = true
            };

            Label lblAddress = new Label
            {
                Text = $"�����: {address}",
                Location = new Point(10, 105),
                AutoSize = true
            };

            // ������� (��������, ����� �������� �� �������� ������)
            Label lblPercent = new Label
            {
                Text = "10%",
                Location = new Point(260, 140),
                Font = new Font("Segoe UI", 14, FontStyle.Bold),
                ForeColor = Color.Green,
                AutoSize = true
            };

            card.Controls.Add(lblName);
            card.Controls.Add(lblEmail);
            card.Controls.Add(lblPhone);
            card.Controls.Add(lblAddress);
            card.Controls.Add(lblPercent);

            return card;
        }

        // ��������������� ������� ��� ��������� email �� ��� (��� ��� � ������� ��� email)
        private string GenerateEmail(string fullName)
        {
            string[] parts = fullName.Split(' ');
            if (parts.Length >= 2)
                return $"{parts[0].ToLower()}.{parts[1].ToLower()}@library.ru";
            return "unknown@library.ru";
        }
        private void topPanel_Paint(object sender, PaintEventArgs e)
        {

        }

        private void flowLayoutPanel_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btnReaders_Click(object sender, EventArgs e)
        {

        }

        private void btnBooks_Click(object sender, EventArgs e)
        {

        }

        private void btnSubscriptions_Click(object sender, EventArgs e)
        {

        }
    }
}
