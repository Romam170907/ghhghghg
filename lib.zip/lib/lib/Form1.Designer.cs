﻿namespace lib
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnReaders = new Button();
            btnBooks = new Button();
            btnSubscriptions = new Button();
            topPanel = new Panel();
            flowLayoutPanel = new FlowLayoutPanel();
            SuspendLayout();
            // 
            // btnReaders
            // 
            btnReaders.Location = new Point(591, 283);
            btnReaders.Name = "btnReaders";
            btnReaders.Size = new Size(75, 23);
            btnReaders.TabIndex = 0;
            btnReaders.Text = "button1";
            btnReaders.UseVisualStyleBackColor = true;
            btnReaders.Click += btnReaders_Click;
            // 
            // btnBooks
            // 
            btnBooks.Location = new Point(591, 336);
            btnBooks.Name = "btnBooks";
            btnBooks.Size = new Size(75, 23);
            btnBooks.TabIndex = 1;
            btnBooks.Text = "button1";
            btnBooks.UseVisualStyleBackColor = true;
            btnBooks.Click += btnBooks_Click;
            // 
            // btnSubscriptions
            // 
            btnSubscriptions.Location = new Point(591, 392);
            btnSubscriptions.Name = "btnSubscriptions";
            btnSubscriptions.Size = new Size(75, 23);
            btnSubscriptions.TabIndex = 2;
            btnSubscriptions.Text = "button1";
            btnSubscriptions.UseVisualStyleBackColor = true;
            btnSubscriptions.Click += btnSubscriptions_Click;
            // 
            // topPanel
            // 
            topPanel.Location = new Point(540, 119);
            topPanel.Name = "topPanel";
            topPanel.Size = new Size(139, 40);
            topPanel.TabIndex = 3;
            topPanel.Paint += topPanel_Paint;
            // 
            // flowLayoutPanel
            // 
            flowLayoutPanel.Location = new Point(29, 219);
            flowLayoutPanel.Name = "flowLayoutPanel";
            flowLayoutPanel.Size = new Size(200, 100);
            flowLayoutPanel.TabIndex = 0;
            flowLayoutPanel.Paint += flowLayoutPanel_Paint;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(topPanel);
            Controls.Add(btnSubscriptions);
            Controls.Add(btnBooks);
            Controls.Add(btnReaders);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
        }

        #endregion

        private Button btnReaders;
        private Button btnBooks;
        private Button btnSubscriptions;
        private Panel topPanel;
        
    }
}
