﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace airport
{
    public partial class AircraftsForm : Form
    {
        private string connectionString = "Server=localhost;Port=3307;Database=airport;Uid=root;Pwd=;";
        private FlowLayoutPanel flowLayoutPanel;
        public AircraftsForm()
        {
            this.Text = "Список самолетов";
            this.Size = new Size(800, 500);

            flowLayoutPanel = new FlowLayoutPanel
            {
                Dock = DockStyle.Fill,
                AutoScroll = true,
                Padding = new Padding(10)
            };

            this.Controls.Add(flowLayoutPanel);
            LoadAircrafts();
        }
        private void LoadAircrafts()
        {
            using (MySqlConnection conn = new MySqlConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    string query = @"
                        SELECT a.aircraft_code, a.name AS aircraft_name, ap.name AS airport_name
                        FROM aircrafts a
                        LEFT JOIN airports ap ON a.airport_code = ap.airport_code";

                    MySqlCommand cmd = new MySqlCommand(query, conn);
                    MySqlDataReader reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {
                        Panel card = new Panel
                        {
                            Width = 350,
                            Height = 120,
                            BorderStyle = BorderStyle.FixedSingle,
                            Margin = new Padding(8),
                            BackColor = Color.WhiteSmoke
                        };

                        card.Controls.Add(new Label
                        {
                            Text = reader["aircraft_name"].ToString(),
                            Font = new Font("Segoe UI", 11, FontStyle.Bold),
                            Location = new Point(5, 5),
                            AutoSize = true
                        });

                        card.Controls.Add(new Label
                        {
                            Text = $"Код: {reader["aircraft_code"]}",
                            Location = new Point(5, 35),
                            AutoSize = true
                        });

                        card.Controls.Add(new Label
                        {
                            Text = $"Базируется в: {reader["airport_name"]}",
                            Location = new Point(5, 60),
                            AutoSize = true
                        });

                        flowLayoutPanel.Controls.Add(card);
                    }
                    reader.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка загрузки: " + ex.Message);
                }
            }
        }
        private void AircraftsForm_Load(object sender, EventArgs e)
        {

        }
    }
}
