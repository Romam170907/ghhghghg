﻿using System;
using System.Drawing;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace airport
{
    public partial class RoutesForm : Form
    {
        private FlowLayoutPanel flowLayoutPanel;
        private string connectionString = "Server=localhost;Port=3307;Database=airport;Uid=root;Pwd=;";
        public RoutesForm()
        {
            this.Text = "Авиамаршруты";
            this.Size = new Size(850, 550);

            flowLayoutPanel = new FlowLayoutPanel
            {
                Dock = DockStyle.Fill,
                AutoScroll = true,
                Padding = new Padding(10)
            };

            this.Controls.Add(flowLayoutPanel);
            LoadRoutes();
        }
        private void LoadRoutes()
        {
            using (MySqlConnection conn = new MySqlConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    string query = @"
                        SELECT r.route_code, 
                               start.name AS start_airport, 
                               end.name AS end_airport,
                               r.flight_hours,
                               base.name AS base_airport,
                               a.name AS aircraft,
                               r.departure_time
                        FROM routes r
                        LEFT JOIN airports start ON r.start_airport_code = start.airport_code
                        LEFT JOIN airports end ON r.end_airport_code = end.airport_code
                        LEFT JOIN airports base ON r.base_airport_code = base.airport_code
                        LEFT JOIN aircrafts a ON r.aircraft_code = a.aircraft_code";

                    MySqlCommand cmd = new MySqlCommand(query, conn);
                    MySqlDataReader reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {
                        Panel card = new Panel
                        {
                            Width = 380,
                            Height = 170,
                            BorderStyle = BorderStyle.FixedSingle,
                            Margin = new Padding(8),
                            BackColor = Color.LightYellow
                        };

                        card.Controls.Add(new Label
                        {
                            Text = $"Маршрут #{reader["route_code"]}",
                            Font = new Font("Segoe UI", 11, FontStyle.Bold),
                            Location = new Point(5, 5),
                            AutoSize = true,
                            ForeColor = Color.DarkRed
                        });

                        card.Controls.Add(new Label
                        {
                            Text = $"Откуда: {reader["start_airport"]}",
                            Location = new Point(5, 35),
                            AutoSize = true
                        });

                        card.Controls.Add(new Label
                        {
                            Text = $"Куда: {reader["end_airport"]}",
                            Location = new Point(5, 60),
                            AutoSize = true
                        });

                        card.Controls.Add(new Label
                        {
                            Text = $"Время в пути: {reader["flight_hours"]} ч.",
                            Location = new Point(5, 85),
                            AutoSize = true
                        });

                        card.Controls.Add(new Label
                        {
                            Text = $"Самолет: {reader["aircraft"]}",
                            Location = new Point(5, 110),
                            AutoSize = true
                        });

                        card.Controls.Add(new Label
                        {
                            Text = $"Вылет: {reader["departure_time"]}",
                            Location = new Point(5, 135),
                            AutoSize = true
                        });

                        flowLayoutPanel.Controls.Add(card);
                    }
                    reader.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка загрузки: " + ex.Message);
                }
            }
        }
        private void RoutesForm_Load(object sender, EventArgs e)
        {

        }
    }
}
