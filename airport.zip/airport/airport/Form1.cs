using System;
using System.Drawing;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
namespace airport
{
    public partial class Form1 : Form
    {
        private string connectionString = "Server=localhost;Port=3307;Database=airport;Uid=root;Pwd=;";
        private Button btnStaff, btnAircrafts, btnRoutes;
        public Form1()
        {
            InitializeComponent();
            SetupUI();
            LoadStaff();
        }
        private void SetupUI()
        {
            this.Text = "������������ - ����������";
            this.Size = new Size(900, 600);

            // ������� ������ � ��������
            Panel topPanel = new Panel
            {
                Height = 50,
                Dock = DockStyle.Top,
                BackColor = Color.LightGray
            };

            btnStaff = new Button
            {
                Text = "����������",
                Location = new Point(10, 10),
                Width = 120
            };

            btnAircrafts = new Button
            {
                Text = "��������",
                Location = new Point(140, 10),
                Width = 120
            };

            btnRoutes = new Button
            {
                Text = "��������",
                Location = new Point(270, 10),
                Width = 120
            };

            btnStaff.Click += (s, e) => LoadStaff();
            btnAircrafts.Click += (s, e) => { new AircraftsForm().ShowDialog(); };
            btnRoutes.Click += (s, e) => { new RoutesForm().ShowDialog(); };

            topPanel.Controls.Add(btnStaff);
            topPanel.Controls.Add(btnAircrafts);
            topPanel.Controls.Add(btnRoutes);

            // FlowLayoutPanel ��� ��������
            flowLayoutPanel = new FlowLayoutPanel
            {
                Dock = DockStyle.Fill,
                AutoScroll = true,
                Padding = new Padding(10),
                FlowDirection = FlowDirection.TopDown,
                WrapContents = true
            };

            this.Controls.Add(flowLayoutPanel);
            this.Controls.Add(topPanel);
        }

        private void LoadStaff()
        {
            flowLayoutPanel.Controls.Clear();

            using (MySqlConnection conn = new MySqlConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    string query = @"
                        SELECT s.inn, s.full_name, p.name AS position, c.name AS crew, sv.name AS service, a.name AS airport
                        FROM staff s
                        LEFT JOIN positions p ON s.position_code = p.position_code
                        LEFT JOIN crews c ON s.crew_code = c.crew_code
                        LEFT JOIN services sv ON s.service_code = sv.service_code
                        LEFT JOIN airports a ON s.airport_code = a.airport_code";

                    MySqlCommand cmd = new MySqlCommand(query, conn);
                    MySqlDataReader reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {
                        string fullName = reader["full_name"].ToString();
                        string position = reader["position"].ToString();
                        string crew = reader["crew"].ToString();
                        string service = reader["service"].ToString();
                        string airport = reader["airport"].ToString();
                        string inn = reader["inn"].ToString();

                        Panel card = CreateStaffCard(fullName, position, crew, service, airport, inn);
                        flowLayoutPanel.Controls.Add(card);
                    }
                    reader.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("������ ��������: " + ex.Message);
                }
            }
        }

        private Panel CreateStaffCard(string fullName, string position, string crew, string service, string airport, string inn)
        {
            Panel card = new Panel
            {
                Width = 340,
                Height = 210,
                BorderStyle = BorderStyle.FixedSingle,
                Margin = new Padding(10),
                BackColor = Color.FromArgb(240, 248, 255)
            };

            // ��� (��� � ������)
            Label lblName = new Label
            {
                Text = fullName,
                Font = new Font("Segoe UI", 12, FontStyle.Bold),
                Location = new Point(10, 10),
                AutoSize = true,
                ForeColor = Color.DarkBlue
            };

            // ��������� (������ email)
            Label lblPosition = new Label
            {
                Text = $"���������: {position}",
                Location = new Point(10, 45),
                AutoSize = true
            };

            // ������ (������ ��������)
            Label lblCrew = new Label
            {
                Text = $"������: {crew ?? "�� ��������"}",
                Location = new Point(10, 75),
                AutoSize = true
            };

            // ������ (������ ������)
            Label lblService = new Label
            {
                Text = $"������: {service ?? "�� ���������"}",
                Location = new Point(10, 105),
                AutoSize = true
            };

            // ��������
            Label lblAirport = new Label
            {
                Text = $"��������: {airport}",
                Location = new Point(10, 135),
                AutoSize = true
            };

            // ������� (��� � ������)
            Label lblPercent = new Label
            {
                Text = "10%",
                Location = new Point(280, 175),
                Font = new Font("Segoe UI", 14, FontStyle.Bold),
                ForeColor = Color.Green,
                AutoSize = true
            };

            card.Controls.Add(lblName);
            card.Controls.Add(lblPosition);
            card.Controls.Add(lblCrew);
            card.Controls.Add(lblService);
            card.Controls.Add(lblAirport);
            card.Controls.Add(lblPercent);

            return card;
        }
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void flowLayoutPanel_Paint(object sender, PaintEventArgs e)
        {

        }

        private void topPanel_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
